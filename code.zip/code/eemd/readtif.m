function data=readtif(path)
data=[];
tiflist = dir(strcat(path, '*.tif'));
tifnum = length(tiflist);
for i=1:tifnum
   image_name = tiflist(i).name;
   da=importdata([path,image_name]);
   da=da(:,1:end);
   da=da(:);
   data=[data da];
end
function k=movingwindows(data1,data2,num,x,y)
%%%data1:independent variable, i.e., NDVI
%%%data2:dependent variable, i.e., El
%%%num:the size of the moving wimdows (odd)
%%%x/y:the row/column of the centre
[a,b]=size(data1);
m=(num-1)/2;%%%the distance between the boundary and  centre; 
a1=max(1,x-m);a2=min(a,x+m);%%%a1:the left boundary of the windows;a2:the right boundary of the windows;
b1=max(1,y-m);b2=min(b,y+m);%%%b1:the top boundary of the windows;b2: the bottom boundary of the windows;
lll=(a2-a1+1)*(b2-b1+1);%%%the number of cells in the windows;
X1=zeros(lll,1)-9999;Y1=zeros(lll,1)-9999;%%X1:all data1 in the windows ;Y1:all data2 in the windows;
kk=1;
for i=a1:a2
    for j=b1:b2
       X1(kk)=data1(i,j);
       Y1(kk)=data2(i,j);
       kk=kk+1;
    end
end
El_diff=max(Y1)-min(Y1);%%the elevation different;
len1=length(find(X1<-1000));%%%the number of invalid values
if len1>ceil(lll/2)||El_diff<50%%%%%whether the number of invalid values were more than half the number of cells in the windows or the elevation different was less than 50 meters 
   k=-9999;%%%_Fillvalue
   return;
end
place=find(X1>-1000);%%%valid values in the windows
len2=length(place);
jj=1;
for ii=1:len2
    X(jj)=X1(place(ii));
    Y(jj)=Y1(place(ii));
    jj=jj+1;
end
XX=[ones(len2,1),Y'];
B=regress(X',XX);
k=B(2);
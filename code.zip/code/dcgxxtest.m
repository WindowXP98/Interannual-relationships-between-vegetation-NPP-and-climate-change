function  [VIF] = dcgxxtest(x)
% x is the matrix to be tested for possible multicollinearity
%Normalize the data
xnew=zscore(x);
%Creating a correlation matrix
guanlian=xnew'*xnew;
%The output of the VIF matrix, with rows greater than 10, indicates that the column variable represented by that row has multicollinearity with the other elements
VIF=diag(inv(guanlian))